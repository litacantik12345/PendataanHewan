/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apkpendataanhewan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author LAB1-31
 */
public class Koneksi {
    
    public static Connection getConnection() {
        Connection conn = null;

        try {
            String url = "jdbc:mysql://localhost:3306/db_hewan";
            String user = "root";
            String password = "";

            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Database berhasil terhubung");

        } catch (SQLException e) {
            System.out.println("Database gagal terhubung");
            System.out.println(e.getMessage());
        }

        return conn;
    }
}
   